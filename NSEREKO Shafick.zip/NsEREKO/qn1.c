/*
//a program without a problem
#include<stdio.h>
int x = 1:
main(){
	if(x=1);
		printf("x equals 1");
	
	otherwise
		printf("x does not equal 1");
	
	return 0;
}*/

/*a program without a problem*/
#include<stdio.h>
int x = 1;
main(){
	if(x=1){
		printf("x equals 1");
	}
	else{
		printf("x does not equal 1");
	}
	return 0;
}
