//#include<stdio.h>
//#include<string.h>
//float do_it(char a, b, c);
//void print_a_number(int x);

/*#include<stdio.h>
void print_msg(void);
main(){
	print_msg("This is a message to print");
	return 0;
}
void print_msq(void)
{
	puts("This is a message to print");
	return 0;
}*/

#include<stdio.h>
void print_msg();
main(){
	print_msg();
	return 0;
	
}
void print_msg()
{
	printf("This is a message to print");
	
}

